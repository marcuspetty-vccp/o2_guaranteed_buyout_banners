FT.manifest({
	"filename": "index.html",
	"width": 728,
	"height": 90,
	"clickTagCount": 1,
	"hideBrowsers":["ie8"],
	"richLoads": [{
		"name": "iRichload",
		"src": "Guaranteed_Buyout_Rich_728x90"
	}],
	"instantAds":[
		{"name": "section2Text", "type": "text", "default": "<h6>Your next upgrade is on us after 12 months<h6>"},
		{"name": "section3Text", "type": "text", "default": "<h6>When you buy the latest phone on our 30GB tariff</h6>"},
		{"name": "ctaText", "type": "text", "default": "Find out more"},
		{"name": "termsText", "type": "text", "default": "Terms apply"},
		{"name": "sectionBtn", "type": "text", "default": "Grab yours now"}
	]
});
