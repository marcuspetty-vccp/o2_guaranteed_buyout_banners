FT.manifest({
	"filename": "index.html",
	"width": 320,
	"height": 50,
	"clickTagCount": 1,
	"hideBrowsers":["ie8"],
	"richLoads": [{
		"name": "iRichload",
		"src": "Guaranteed_Buyout_Rich_320x50"
	}],
	"instantAds":[

		{"name": "section2Text", "type": "text", "default": "<h6>Your next upgrade is on us after 12 months</h6>"},
		{"name": "section3Text", "type": "text", "default": "<h6><h6>When you buy the latest<br/>phone on our 30GB tariff</h6></h6>"},
		{"name": "ctaText", "type": "text", "default": "Find out more"},
		{"name": "termsText", "type": "text", "default": "Terms apply"}

	]
});
